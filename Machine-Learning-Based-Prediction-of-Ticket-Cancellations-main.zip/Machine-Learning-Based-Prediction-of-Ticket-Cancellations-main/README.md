# Machine-Learning-Based-Prediction-of-Ticket-Cancellations
This project tackles a critical challenge for MrBilit: predicting user ticket cancellations to mitigate costly penalty fees from transportation companies. Our machine learning model achieves an impressive ** 99% accuracy** on test data, empowering MrBilit to proactively manage risk.
